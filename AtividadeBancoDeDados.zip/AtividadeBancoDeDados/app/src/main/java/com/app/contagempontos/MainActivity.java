package com.app.contagempontos;


import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.intellij.lang.annotations.Language;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {


    private TextView titleTV, partidaTV, nPontoTV1, nPontoTV2;
    private EditText partidaET, equipe1ET, equipe2ET;
    private Button maisPontoBtn1, menosPontoBtn1, maisPontoBtn2, menosPontoBtn2, resetBtn, historicoBtn;
    private int pontuacaoMax;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Text View
        titleTV = findViewById(R.id.titleTV);
        partidaTV = findViewById(R.id.partidaTV);
        nPontoTV1 = findViewById(R.id.nPontoTV1);
        nPontoTV2 = findViewById(R.id.nPontoTV2);
        // Edit Text
        partidaET = findViewById(R.id.partidaET);
        equipe1ET = findViewById(R.id.equipe1ET);
        equipe2ET = findViewById(R.id.equipe2ET);
        // Buttons
        maisPontoBtn1 = findViewById(R.id.maisPontoBtn1);
        menosPontoBtn1 = findViewById(R.id.menosPontoBtn1);
        maisPontoBtn2 = findViewById(R.id.maisPontoBtn2);
        menosPontoBtn2 = findViewById(R.id.menosPontoBtn2);
        resetBtn = findViewById(R.id.resetBtn);
        historicoBtn = findViewById(R.id.historicoBtn);

        // Botões aumentar ponto
        maisPontoBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                aumentar(nPontoTV1);
                checarVitoria(nPontoTV1, equipe1ET);
            }
        });
        maisPontoBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                aumentar(nPontoTV2);
                checarVitoria(nPontoTV2, equipe2ET);
            }
        });

        // Botões diminuir ponto
        menosPontoBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                diminuir(nPontoTV1);
            }
        });
        menosPontoBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                diminuir(nPontoTV2);
            }
        });

        //Detectar numero de pontos da partida
        partidaET.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                try{
                    pontuacaoMax = Integer.parseInt(partidaET.getText().toString());
                    partidaET.setEnabled(false);
                }catch(Exception e){
                    Toast.makeText(getApplicationContext(), "Coloque um número valido", Toast.LENGTH_SHORT).show();
                    partidaET.setText("");
                }
            }
        });

        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                titleTV.setText("Pitoco Counter");
                partidaET.setEnabled(true);
                partidaET.setText("");
                pontuacaoMax = 0;

                equipe1ET.setEnabled(true);
                equipe1ET.setText("");

                equipe2ET.setEnabled(true);
                equipe2ET.setText("");

                nPontoTV1.setText("0");
                nPontoTV2.setText("0");

                maisPontoBtn1.setEnabled(true);
                menosPontoBtn1.setEnabled(true);
                maisPontoBtn2.setEnabled(true);
                menosPontoBtn2.setEnabled(true);
            }
        });

        historicoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), ListagemPartidas.class);
                startActivity(i);
            }
        });

    }

    public void aumentar(TextView tv){
        int numero = Integer.parseInt(tv.getText().toString());
        numero++;
        tv.setText(String.valueOf(numero));
    }

    public void diminuir(TextView tv){
        int numero = Integer.parseInt(tv.getText().toString());
        if(numero == 0) {
            Toast.makeText(getApplicationContext(), "Pontuação 0", Toast.LENGTH_SHORT).show();
            return;
        }
        numero--;
        tv.setText(String.valueOf(numero));
    }

    public void checarVitoria(TextView tv, EditText et){
        if(Integer.parseInt(tv.getText().toString()) == pontuacaoMax) {
            String vencedor = et.getText().toString();
            String mensagem = vencedor + " ganhou!";
            titleTV.setText(mensagem);
            Toast.makeText(getApplicationContext(), mensagem, Toast.LENGTH_SHORT).show();
            partidaET.setEnabled(false);
            equipe1ET.setEnabled(false);
            equipe2ET.setEnabled(false);
            maisPontoBtn1.setEnabled(false);
            menosPontoBtn1.setEnabled(false);
            maisPontoBtn2.setEnabled(false);
            menosPontoBtn2.setEnabled(false);
            registrarPartida(equipe1ET, equipe2ET, nPontoTV1, nPontoTV2, vencedor);
        }
    }

    public void registrarPartida(EditText jogador1, EditText jogador2, TextView pontos1, TextView pontos2, String vencedor){
        SQLiteDatabase db = new PartidasBanco(this).getWritableDatabase();

        Date hoje = new Date();
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss", Locale.getDefault());
        String data = format.format(hoje);

        ContentValues valores = new ContentValues();

        valores.put("data", data);
        valores.put("jogador1", jogador1.getText().toString());
        valores.put("jogador2", jogador2.getText().toString());
        valores.put("pontos1", Integer.parseInt(pontos1.getText().toString()));
        valores.put("pontos2", Integer.parseInt(pontos2.getText().toString()));
        valores.put("vencedor", vencedor);
        db.insert("partidas", null, valores);
    }
}

