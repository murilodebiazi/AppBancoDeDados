package com.app.contagempontos;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class ListagemPartidas extends AppCompatActivity {
    private ListView listaPartidas;
    private AdapterPartidas adapterPartidas;
    private PartidasBanco db;
    private Button voltarBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_listagem_partidas);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listaPartidas = findViewById(R.id.listaPartidas);
        voltarBtn = findViewById(R.id.voltarBtn);
        adapterPartidas = new AdapterPartidas(getApplicationContext(), R.layout.item_partida);
        db = new PartidasBanco(getApplicationContext());
        SQLiteDatabase partidas = db.getReadableDatabase();

        Cursor cursor = partidas.query("partidas", null, null, null, null, null, null);

        listaPartidas.setAdapter(adapterPartidas);

        while(cursor.moveToNext()) {
            long itemId = cursor.getInt(
                    cursor.getColumnIndexOrThrow("id"));
            String jogador1 = cursor.getString(cursor.getColumnIndexOrThrow("jogador1"));
            String jogador2 = cursor.getString(cursor.getColumnIndexOrThrow("jogador2"));
            String pontos1 = cursor.getString(cursor.getColumnIndexOrThrow("pontos1"));
            String pontos2 = cursor.getString(cursor.getColumnIndexOrThrow("pontos2"));
            String data = cursor.getString(cursor.getColumnIndexOrThrow("data"));
            String vencedor = cursor.getString(cursor.getColumnIndexOrThrow("vencedor"));
            String resultado1 = "";
            String resultado2 = "";

            if(jogador1.equalsIgnoreCase(vencedor)){
                resultado1 = "Vitória";
                resultado2 = "Derrota";
            }else{
                resultado1 = "Derrota";
                resultado2 = "Vitória";
            }

            adapterPartidas.add(new Partida(jogador1,jogador2,pontos1,pontos2,resultado1,resultado2,data));
        }
        cursor.close();

        voltarBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
            }
        });
    }
}