package com.app.contagempontos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PartidasBanco extends SQLiteOpenHelper {
    public PartidasBanco(Context context){
        super(context,"meuapp.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE partidas (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "data TEXT, jogador1 TEXT, jogador2 TEXT, pontos1 INT, pontos2 INT, vencedor TEXT)" );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        db.execSQL("DROP TABLE IF EXISTS usuarios");
        onCreate(db);
    }


}
