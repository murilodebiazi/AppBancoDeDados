package com.app.contagempontos;

public class Partida {
    private String jogador1, jogador2, pontos1, pontos2, resultado1, resultado2, data;

    public Partida(String jogador1, String jogador2, String pontos1, String pontos2, String resultado1, String resultado2, String data) {
        this.jogador1 = jogador1;
        this.jogador2 = jogador2;
        this.pontos1 = pontos1;
        this.pontos2 = pontos2;
        this.resultado1 = resultado1;
        this.resultado2 = resultado2;
        this.data = data;
    }

    public String getJogador1() {
        return jogador1;
    }

    public void setJogador1(String jogador1) {
        this.jogador1 = jogador1;
    }

    public String getJogador2() {
        return jogador2;
    }

    public void setJogador2(String jogador2) {
        this.jogador2 = jogador2;
    }

    public String getPontos1() {
        return pontos1;
    }

    public void setPontos1(String pontos1) {
        this.pontos1 = pontos1;
    }

    public String getPontos2() {
        return pontos2;
    }

    public void setPontos2(String pontos2) {
        this.pontos2 = pontos2;
    }

    public String getResultado1() {
        return resultado1;
    }

    public void setResultado1(String resultado1) {
        this.resultado1 = resultado1;
    }

    public String getResultado2() {
        return resultado2;
    }

    public void setResultado2(String resultado2) {
        this.resultado2 = resultado2;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}

