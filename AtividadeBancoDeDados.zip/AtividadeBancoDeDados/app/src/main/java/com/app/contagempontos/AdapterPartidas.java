package com.app.contagempontos;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

public class AdapterPartidas extends ArrayAdapter<Partida> {

    public AdapterPartidas(@NonNull Context context, int resource){
        super(context,resource);
    }

    @SuppressLint("ResourceAsColor")
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        if(convertView == null){
            LayoutInflater inflater = LayoutInflater.from(getContext().getApplicationContext());
            convertView = inflater.inflate(R.layout.item_partida, parent, false);
        }

        Partida partida = getItem(position);

        TextView jogador1 = convertView.findViewById(R.id.jogador1);
        TextView jogador2 = convertView.findViewById(R.id.jogador2);
        TextView pontos1 = convertView.findViewById(R.id.pontos1);
        TextView pontos2 = convertView.findViewById(R.id.pontos2);
        TextView resultado1 = convertView.findViewById(R.id.resultado1);
        TextView resultado2 = convertView.findViewById(R.id.resultado2);
        TextView data = convertView.findViewById(R.id.data);

        jogador1.setText(partida.getJogador1());
        jogador2.setText(partida.getJogador2());
        pontos1.setText(partida.getPontos1());
        pontos2.setText(partida.getPontos2());
        resultado1.setText(partida.getResultado1());
        resultado2.setText(partida.getResultado2());
        data.setText(partida.getData());

        if(partida.getResultado1().equals("Vitória")){
            resultado1.setTextColor(ContextCompat.getColor(getContext(), R.color.green));
            resultado2.setTextColor(ContextCompat.getColor(getContext(), R.color.red));
            pontos1.setTextColor(ContextCompat.getColor(getContext(), R.color.green));
            pontos2.setTextColor(ContextCompat.getColor(getContext(), R.color.red));
        }else{
            resultado1.setTextColor(ContextCompat.getColor(getContext(), R.color.red));
            resultado2.setTextColor(ContextCompat.getColor(getContext(), R.color.green));
            pontos1.setTextColor(ContextCompat.getColor(getContext(), R.color.red));
            pontos2.setTextColor(ContextCompat.getColor(getContext(), R.color.green));
        }

        return convertView;
    }
}
